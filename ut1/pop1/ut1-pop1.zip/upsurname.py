# ********************************
# APELLIDO EN MAYÚSCULAS, SUMA UNO
# ********************************


def run(fullname: str) -> int:
    is_mayus = fullname.isupper()
    index_comma = fullname.find(',')
    erasing_left_side = fullname.lstrip(str(index_comma))

    fmetric = erasing_left_side
    return fmetric


if __name__ == '__main__':
    run('Kernighan,Brian')
