# *********************************
# ENCONTRANDO REPETICIÓN DE VOCALES
# *********************************


def run(text: str) -> int:
    text.lower()
    vocals = 'aeiou'
    text.find(vocals)
    nrep = text.find(vocals)

    return nrep


if __name__ == '__main__':
    run('aaaantequera')
