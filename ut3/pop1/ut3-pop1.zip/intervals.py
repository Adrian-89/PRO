# ********************
# INTERVALO DESPLEGADO
# ********************


def run(interval: str) -> list:
    # TU CÓDIGO AQUÍ
    irange = 'output'

    return irange


if __name__ == '__main__':
    run('[3,10]')