# ***************************
# BUSCANDO LA MAYOR DISTANCIA
# ***************************


def run(values: list, target: int) -> int:
    # operation = abs(int(items) - target)
    max_value = values[0]
    for value in values:
        if value > max_value:
            max_value = value
        max_value = value
        operation = abs(value - target)
        elif operation == ta

    for items in values:
        numbers = items
        op = abs(numbers - target)
        if value == op:
            result = op

    max_diff = result

    return max_diff


if __name__ == '__main__':
    run([7, 3, 1, 12, 21, 4], 8)
