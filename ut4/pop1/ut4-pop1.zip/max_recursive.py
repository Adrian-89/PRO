# *************************************
# CALCULANDO EL MÁXIMO CON RECURSIVIDAD
# *************************************


def rmax(items: list) -> int: 
    for item in items:
        if item[0] 

