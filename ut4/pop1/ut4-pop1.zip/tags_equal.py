# **********************
# ETIQUETAS EQUIVALENTES
# **********************


# def equal_calc(item: str):
#   pass


def run(tag1: str, tag2: str) -> bool:
    
